import {Vector3} from "../../../three/src/math/Vector3";
import {Quaternion} from "../../../three/src/math/Quaternion";
import {Mesh} from "../../../three/src/objects/Mesh";
import {Group} from "../../../three/src/objects/Group";

export class MapMetaObject {

    private reference: string;
    private translation: Vector3;
    private rotation: Quaternion;
    private scale: Vector3;

    constructor(reference:string, translation:Vector3, rotation:Quaternion, scale:Vector3){
        this.reference = reference;
        this.translation = translation;
        this.rotation = rotation;
        this.scale = scale;
    }

}