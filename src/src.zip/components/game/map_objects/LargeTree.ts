import {BaseMapObject, InterfaceMapObject} from "../base/BaseMapObject";
import {Group} from "../../../three/src/objects/Group";
import {Scene} from "../../../three/src/scenes/Scene";
import {Vector3} from "../../../three/src/math/Vector3";
import {WebGLRenderer} from "../../../three/src/renderers/WebGLRenderer";
import {Object3D} from "../../../three/src/core/Object3D";
import {GLTFLoader} from "../../../three/examples/jsm/loaders/GLTFLoader";
import {TextureLoader} from "../../../three/src/loaders/TextureLoader";
import {MeshPhongMaterial} from "../../../three/src/materials/MeshPhongMaterial";
import {DDSLoader} from "../../../three/examples/jsm/loaders/DDSLoader";
import {CompressedTexture} from "../../../three/src/textures/CompressedTexture";
import {
    DoubleSide,
    NormalBlending
} from "../../../three/src/constants";
import {BoxBufferGeometry} from "../../../three/src/geometries/BoxBufferGeometry";
import {MeshBasicMaterial} from "../../../three/src/materials/MeshBasicMaterial";

/**
 * Большая такая сосна красивая
 */
export class LargeTree extends BaseMapObject implements InterfaceMapObject {
    objectGroup: Group;

    loadObject(onLoad: (mapObject: InterfaceMapObject) => void) {
        const self = this;

        const loader = new GLTFLoader();
        loader.load('/models/gltf/tree_large.glb', function ( gltf: GLTFLoader ) {

            gltf.scene.traverse( function ( child: Object3D ) {

                if ( child.isMesh ) {

                    child.scale.set(20, 20, 20);

                    console.log(child);
                    if(child.name === 'tree') {
                        let texture = new TextureLoader().load('/textures/tree/1.jpg')
                        texture.wrapS = 1001
                        texture.wrapT = 1001
                        child.material = new MeshPhongMaterial({
                            map: texture,
                            flatShading:false,
                            /*wireframe: true,
                            wireframeLinecap: 'butt'*/
                        })
                        child.material.map.repeat.set(20, 1)
                        child.material.map.wrapS = 1000
                        child.material.map.wrapT = 1000
                        child.material.map.encoding = 3001
                        child.material.side = 2
                        child.receiveShadow = true
                        child.castShadow = true
                    }

                    if(child.name === 'leaves') {
                        const loader = new DDSLoader();
                        loader.load( '/textures/tree/hepatica_dxt3_mip.dds', (texture: CompressedTexture) => {



                            //child.geometry = new BoxBufferGeometry( 10, 10, 10 );


                            child.material = new MeshBasicMaterial( { map: texture, side: DoubleSide, blending: NormalBlending, depthTest: false, transparent: true } );
                            child.material.needsUpdate = true;
                            child.material.map.repeat.set(1, 1)
                            child.material.map.wrapS = 1000
                            child.material.map.wrapT = 1000
                            child.material.map.encoding = 3001
                            child.material.side = 2


                        });
                    }

                }

            } );

            gltf.scene.scale.set(0,0,0);
            self.objectGroup = gltf.scene;
            onLoad(self);

        } );


    }


    getPosition(): Vector3 {
        return this.objectGroup.position;
    }

    setPosition(position: Vector3): void {
        this.objectGroup.position.copy(position);
    }

    addToScene(scene: Scene): void {
        let self = this;

        scene.add(self.objectGroup)
    }

    removeFromScene(scene: Scene): void {
        //scene.remove(this.objectGroup);
    }

    clone(){
        this.objectGroup = this.objectGroup.clone();
    }

    hide(){
        this.objectGroup.visible = false;
        this.objectGroup.matrixAutoUpdate = false;
    }

    show(){
        this.objectGroup.visible = true;
        this.objectGroup.matrixAutoUpdate = true;
    }
}