export interface UpdatebleInterface {
    update(delta:number):void
}