import {Mesh} from "../../../three/src/objects/Mesh";
import {Texture} from "../../../three/src/textures/Texture";
import {Scene} from "../../../three/src/scenes/Scene";
import {PlaneBufferGeometry} from "../../../three/src/geometries/PlaneBufferGeometry";
import {TextureLoader} from "../../../three/src/loaders/TextureLoader";
import {ImprovedNoise} from "../../../three/examples/jsm/math/ImprovedNoise";
import {MeshPhongMaterial} from "../../../three/src/materials/MeshPhongMaterial";
import {
    DoubleSide,
    NearestFilter,
    NormalMapTypes,
    ObjectSpaceNormalMap,
    RepeatWrapping
} from "../../../three/src/constants";
import {Box3} from "../../../three/src/math/Box3";
import {MeshStandardMaterial} from "../../../three/src/materials/MeshStandardMaterial";
import {Color} from "../../../three/src/math/Color";
import {Vector2} from "../../../three/src/math/Vector2";
import {GLTF, GLTFLoader} from "../../../three/examples/jsm/loaders/GLTFLoader";
import {Object3D} from "../../../three/src/core/Object3D";
import {Group} from "../../../three/src/objects/Group";
import {SplatBlendMaterial} from "../materials/SplatBlendMaterial";
import {ShaderMaterial} from "../../../three/src/materials/ShaderMaterial";
import {Vector3} from "../../../three/src/math/Vector3";
import {WebGLRenderer} from "../../../three/src/renderers/WebGLRenderer";
import {MapObjectService} from "../services/MapObjectService";
import {PlaneGeometry} from "../../../three/src/geometries/PlaneGeometry";
import {MeshBasicMaterial} from "../../../three/src/materials/MeshBasicMaterial";
import {Box3Helper} from "../../../three/src/helpers/Box3Helper";

export class ForestGround {

    private readonly FILE_KEY_SCALE_CONTAINER: string = 'scale_container';
    private readonly FILE_KEY_SECTORS: string = 'sectors';
    private readonly FILE_KEY_INDEXED_OBJECTS: string = 'indexed_objects';
    private readonly FILE_KEY_OBJECTS: string = 'objects';
    private readonly FILE_KEY_START_POINT: string = 'start_point';

    private readonly WIDTH_SECTORS = 8;
    private readonly HEIGHT_SECTORS = 8;

    scene: Scene;
    mesh: Mesh | Group;

    private focusPosition: Vector3;
    private currentSector: Mesh | Group = null;
    private besideSectors: Array<Mesh | Group> = [];

    /**
     * Сектора земли карты
     *
     * пронумерованные с 1 по 64 слево направо свеху вниз
     * подобная нумерация позволяет легко высчитывать ближайшие сектора к персонажу не прибегая
     * к distanceTo() к каждому сектору на карте
     */
    public sectors: Array<Mesh | Group> = [];

    /**
     * Объекты на карте по номерам секторов
     *
     * подобная нумерация позволяет легко высчитывать ближайшие объекты к персонажу не прибегая к distanceTo()
     * ко всем объектам на карте. Иными словами при определении какие объекты показывать высчитывается по distanceTo()
     * только объекты из ближайших секторов
     */
    protected indexed_objects: Array<Mesh | Group> = [];

    /**
     * Все остальные объекты на карте
     */
    protected objects: Array<Mesh | Group> = [];

    constructor(scene: Scene, onLoad) {
        this.scene = scene;

        let loader = new GLTFLoader();

        loader.load('/models/worlds/new_test.glb', (gltf: GLTF) => {
            gltf.scene.children.forEach((children: Mesh | Group | Object3D, index: number) => {
                //this.scene.add(gltf.scene);
                if (children.name === this.FILE_KEY_SCALE_CONTAINER) {
                    children.children.forEach((subchildren: Mesh | Group | Object3D, index: number) => {

                        if (subchildren.type === 'Mesh' || subchildren.type === 'Group' || subchildren.type === 'Object3D') {

                            if (subchildren.name === this.FILE_KEY_SECTORS) {
                                this.loadGroundSectors(subchildren);
                            }
                            if (subchildren.name === this.FILE_KEY_INDEXED_OBJECTS) {
                                this.loadIndexedMapObjects(subchildren);
                            }
                            if (subchildren.name === this.FILE_KEY_OBJECTS) {
                                this.loadObjects(subchildren);
                            }
                        }

                    });
                }
            });

            gltf = null;
            onLoad(this);

        });
        loader = null;

    }

    public getCurrentSector()
    {
        return this.currentSector;
    }

    public geBesideSectors(limit:number)
    {
        let array = this.besideSectors;
        if (limit > 0) {
            array.length = limit;
        }
        return array;
    }

    /**
     * Передать фокусную позицию
     *
     * по усмотрению нужно передавать тогда, когда нужно перестроить мир для его корректного
     * отображения по отношению к тому что мы сейчас наблюдаем
     *
     * например при перемещении персонажа или камеры
     *
     * @param position Vector3
     * @param rebuild boolean
     */
    public setFocusPosition(position: Vector3, rebuild: boolean = true) {
        this.focusPosition = position;
        if (rebuild === true) {
            this.rebuildWorld();
        }
    }

    private rebuildWorld() {

        this.mesh.children = [];

        let distanceData = [];
        let vectorPosition = new Vector3();
        let sectors = [];
        if (this.besideSectors.length < 1) {
            sectors = this.sectors;
        } else {
            sectors = this.besideSectors;
        }

        sectors.forEach((sector: Mesh | Group | Object3D, index: number) => {
            distanceData.push({
                distance: this.focusPosition.distanceTo(sector.getWorldPosition(vectorPosition)),
                sector: sector
            });
        });
        distanceData.sort((a: any, b: any) => {
            return a.distance - b.distance;
        });

        this.currentSector = distanceData[0].sector;
        this.mesh.add(this.currentSector);

        let sector_number = distanceData[0].sector.name.replace('sector', '');
        let beside_sectors = this.getBesideSectors(sector_number);
        beside_sectors.forEach((sector: Mesh | Group) => {
            this.besideSectors.push(sector);
            this.mesh.add(sector);
        });

        console.log(this.currentSector);
    }

    private getBesideSectors(current_number: string): Array<Mesh | Group> {
        let number:number = parseInt(current_number);
        //9 секторов, чтоб получился квадрат 3х3 сектора, а в центре - полученый ближайший сектор
        let beside_numbers = [
            number - this.WIDTH_SECTORS - 1,
            number - this.WIDTH_SECTORS,
            number - this.WIDTH_SECTORS + 1,
            number - 1,
            number + 1,
            number + this.WIDTH_SECTORS - 1,
            number + this.WIDTH_SECTORS,
            number + this.WIDTH_SECTORS + 1,
        ];
        let result = [];
        beside_numbers.forEach((number: number) => {
            if (this.sectors[number]) {
                result.push(this.sectors[number]);
            }
        });
        //console.log(result);
        return result;
    }

    private loadGroundSectors(sectors: Mesh | Group): void {

        this.mesh = new Mesh();
        this.mesh.scale.set(12, 12, 12);
        this.mesh.position.set(50000, 50000, 50000);

        let textureLoader = new TextureLoader();
        let defaultMaterial = new MeshStandardMaterial({
            map: textureLoader.load('/textures/3docean-bOFtHozc-the-painted-desert-ground-seamless-texture/Texture.jpg'),
            normalMap: textureLoader.load('/textures/3docean-bOFtHozc-the-painted-desert-ground-seamless-texture/Normal.jpg'),
            lightMap: textureLoader.load('/textures/3docean-bOFtHozc-the-painted-desert-ground-seamless-texture/Specular.jpg'),
            bumpMap: textureLoader.load('/textures/3docean-bOFtHozc-the-painted-desert-ground-seamless-texture/Occlusion.jpg'),
        });
        defaultMaterial.side = 2;

        defaultMaterial.map.wrapT = defaultMaterial.map.wrapS = RepeatWrapping;
        defaultMaterial.normalMap.wrapT = defaultMaterial.normalMap.wrapS = RepeatWrapping;
        defaultMaterial.lightMap.wrapT = defaultMaterial.lightMap.wrapS = RepeatWrapping;
        defaultMaterial.bumpMap.wrapT = defaultMaterial.bumpMap.wrapS = RepeatWrapping;

        defaultMaterial.map.repeat.set(4, 4);
        defaultMaterial.normalMap.repeat.set(4, 4);
        defaultMaterial.lightMap.repeat.set(4, 4);
        defaultMaterial.bumpMap.repeat.set(4, 4);


        let i = 0;
        //console.log(sectors);
        sectors.children.forEach((children: Mesh | Group | Object3D, index: number) => {
            let name = children.name.replace('sector', '');
            this.sectors[name] = children.clone(true);
            i++;

            this.sectors[name].material = defaultMaterial;
        });
        sectors.clear();
        sectors = null;

        this.sectors.forEach((children: Mesh | Group | Object3D) => {
            children.updateMatrix();
            children.matrixAutoUpdate = false;
            this.mesh.add(children);
        });

        this.scene.add(this.mesh);

        this.currentSector = this.sectors[28];
        console.log("currentSector");
        console.log(this.currentSector);
    }

    private loadIndexedMapObjects(indexed_objects: Mesh | Group): void {
        let serv = MapObjectService.Instance;
        indexed_objects.children.forEach((children: Mesh | Group, index: number) => {
            if (typeof this.indexed_objects[children.name] === 'undefined') {
                this.indexed_objects[children.name] = [];
            }
            children.children.forEach((subchildren: Mesh | Group) => {
                this.indexed_objects[children.name].push(serv.createMetaObjectFromMesh(subchildren));
            });
        });
        //console.log(this.indexed_objects);
    }

    private loadObjects(objects: Mesh | Group): void {
        objects.children.forEach((children: Mesh | Group) => {
            this.objects.push(children.clone(true));
        });
    }

    private update(delta: number, renderer: WebGLRenderer) {
        //console.log(delta);
    }
}
