export class StringHelper {

}