export class AnimationConfig {

}
